"""
rust-kgdb Python SDK
High-performance RDF/SPARQL database with 100% W3C compliance

Quick Start:
    >>> from rust_kgdb_py import GraphDb
    >>> db = GraphDb("http://example.org/my-app")
    >>> db.load_ttl('<http://ex.org/alice> <http://xmlns.com/foaf/0.1/name> "Alice" .', None)
    >>> results = db.query_select('SELECT ?name WHERE { ?person <http://xmlns.com/foaf/0.1/name> ?name }')
    >>> print(results[0].bindings["name"])  # "Alice"
"""

__version__ = "0.1.3"

from .gonnect import (
    GraphDb,
    QueryResult,
    TripleResult,
    DatabaseStats,
    PerformanceStats,
    GonnectError,
    get_version,
)

__all__ = [
    "GraphDb",
    "QueryResult",
    "TripleResult",
    "DatabaseStats",
    "PerformanceStats",
    "GonnectError",
    "get_version",
]
