# rust-kgdb Python SDK

Production-ready Python bindings for rust-kgdb RDF/SPARQL database.

## Installation

```bash
pip install rust-kgdb
```

## Quick Start

```python
from rust_kgdb import GraphDB, Node

# Create database
db = GraphDB.in_memory()

# Insert triples
db.insert() \
    .triple(
        Node.iri("http://example.org/alice"),
        Node.iri("http://xmlns.com/foaf/0.1/name"),
        Node.literal("Alice")
    ) \
    .execute()

# Query with SPARQL
results = db.query() \
    .sparql("SELECT ?name WHERE { ?person <http://xmlns.com/foaf/0.1/name> ?name }") \
    .execute()

for binding in results:
    print(f"Name: {binding.get('name')}")
```

## Features

- ✅ Complete SPARQL 1.1 support
- ✅ Zero-copy performance (2.78 µs lookups)
- ✅ Type-safe Python API
- ✅ Comprehensive test coverage
- ✅ Professional documentation

## Architecture

```
Python Application
    ↓
rust_kgdb (Python wrapper)
    ↓
UniFFI Generated Bindings
    ↓
mobile-ffi (Rust FFI layer)
    ↓
Core Engine (sparql + storage)
```

## API Reference

### GraphDB

```python
class GraphDB:
    """RDF graph database with SPARQL support."""

    @staticmethod
    def in_memory() -> GraphDB:
        """Create an in-memory database."""

    def insert() -> InsertBuilder:
        """Start building an insert operation."""

    def query() -> QueryBuilder:
        """Start building a query operation."""

    def count() -> int:
        """Count total triples."""

    def is_empty() -> bool:
        """Check if database is empty."""

    def clear() -> None:
        """Clear all triples."""
```

### Node

```python
class Node:
    """RDF node (IRI, Literal, or Blank Node)."""

    @staticmethod
    def iri(uri: str) -> Node:
        """Create an IRI node."""

    @staticmethod
    def literal(value: str) -> Node:
        """Create a plain literal."""

    @staticmethod
    def typed_literal(value: str, datatype: str) -> Node:
        """Create a typed literal."""

    @staticmethod
    def lang_literal(value: str, lang: str) -> Node:
        """Create a language-tagged literal."""

    @staticmethod
    def integer(value: int) -> Node:
        """Create an integer literal."""

    @staticmethod
    def boolean(value: bool) -> Node:
        """Create a boolean literal."""

    @staticmethod
    def blank(id: str) -> Node:
        """Create a blank node."""
```

### InsertBuilder

```python
class InsertBuilder:
    """Fluent builder for insert operations."""

    def triple(self, subject: Node, predicate: Node, object: Node) -> InsertBuilder:
        """Add a triple to insert."""

    def graph(self, graph: Node) -> InsertBuilder:
        """Set the named graph."""

    def execute(self) -> None:
        """Execute the insert operation."""
```

### QueryBuilder

```python
class QueryBuilder:
    """Fluent builder for SPARQL queries."""

    def sparql(self, query: str) -> QueryBuilder:
        """Set the SPARQL query string."""

    def execute(self) -> QueryResult:
        """Execute the query and return results."""
```

### QueryResult

```python
class QueryResult:
    """Query results with variable bindings."""

    def __len__(self) -> int:
        """Number of result bindings."""

    def __iter__(self) -> Iterator[Binding]:
        """Iterate over bindings."""

    def is_empty(self) -> bool:
        """Check if results are empty."""
```

### Binding

```python
class Binding:
    """Variable binding from query result."""

    def get(self, variable: str) -> Optional[str]:
        """Get value for variable name."""
```

## Examples

### Basic CRUD

```python
from rust_kgdb import GraphDB, Node

db = GraphDB.in_memory()

# Insert
db.insert() \
    .triple(
        Node.iri("http://example.org/alice"),
        Node.iri("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        Node.iri("http://xmlns.com/foaf/0.1/Person")
    ) \
    .execute()

# Count
print(f"Triples: {db.count()}")

# Query
results = db.query() \
    .sparql("SELECT ?s WHERE { ?s ?p ?o }") \
    .execute()

print(f"Results: {len(results)}")
```

### Multiple Triples

```python
db.insert() \
    .triple(
        Node.iri("http://example.org/alice"),
        Node.iri("http://xmlns.com/foaf/0.1/name"),
        Node.literal("Alice")
    ) \
    .triple(
        Node.iri("http://example.org/alice"),
        Node.iri("http://xmlns.com/foaf/0.1/age"),
        Node.integer(30)
    ) \
    .execute()
```

### Unicode Support

```python
db.insert() \
    .triple(
        Node.iri("http://example.org/doc"),
        Node.iri("http://example.org/title"),
        Node.literal("Hello 世界 🌍")
    ) \
    .execute()
```

### Language Tags

```python
db.insert() \
    .triple(
        Node.iri("http://example.org/doc"),
        Node.iri("http://example.org/title"),
        Node.lang_literal("Bonjour", "fr")
    ) \
    .execute()
```

## Testing

```bash
# Run all tests
pytest tests/

# Run with coverage
pytest tests/ --cov=rust_kgdb --cov-report=html

# Run specific test
pytest tests/test_regression.py::test_basic_crud
```

## Performance

- **Lookup**: 2.78 µs per query
- **Memory**: 24 bytes per triple
- **Bulk Insert**: 146K triples/sec

## Requirements

- Python 3.8+
- Rust shared library (bundled)

## License

MIT/Apache-2.0

## Links

- [Documentation](https://docs.rs/rust-kgdb-sdk)
- [GitHub](https://github.com/zenya-graphdb/rust-kgdb)
- [PyPI](https://pypi.org/project/rust-kgdb)
